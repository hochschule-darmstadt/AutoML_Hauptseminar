# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import json
import logging
import os
import pickle
import numpy as np
import pandas as pd
import joblib

import azureml.automl.core
from azureml.automl.core.shared import logging_utilities, log_server
from azureml.telemetry import INSTRUMENTATION_KEY

from inference_schema.schema_decorators import input_schema, output_schema
from inference_schema.parameter_types.numpy_parameter_type import NumpyParameterType
from inference_schema.parameter_types.pandas_parameter_type import PandasParameterType


input_sample = pd.DataFrame({"UNITID": pd.Series([0], dtype="int64"), "school_name": pd.Series(["example_value"], dtype="object"), "city": pd.Series(["example_value"], dtype="object"), "state": pd.Series(["example_value"], dtype="object"), "zip": pd.Series(["example_value"], dtype="object"), "school_webpage": pd.Series(["example_value"], dtype="object"), "latitude": pd.Series(["example_value"], dtype="object"), "longitude": pd.Series(["example_value"], dtype="object"), "admission_rate": pd.Series(["example_value"], dtype="object"), "sat_verbal_midrange": pd.Series(["example_value"], dtype="object"), "sat_math_midrange": pd.Series(["example_value"], dtype="object"), "sat_writing_midrange": pd.Series(["example_value"], dtype="object"), "act_combined_midrange": pd.Series(["example_value"], dtype="object"), "act_english_midrange": pd.Series(["example_value"], dtype="object"), "act_math_midrange": pd.Series(["example_value"], dtype="object"), "act_writing_midrange": pd.Series(["example_value"], dtype="object"), "sat_total_average": pd.Series(["example_value"], dtype="object"), "undergrad_size": pd.Series([0.0], dtype="float64"), "percent_white": pd.Series([0.0], dtype="float64"), "percent_black": pd.Series([0.0], dtype="float64"), "percent_hispanic": pd.Series([0.0], dtype="float64"), "percent_asian": pd.Series([0.0], dtype="float64"), "percent_part_time": pd.Series([0.0], dtype="float64"), "average_cost_academic_year": pd.Series(["example_value"], dtype="object"), "average_cost_program_year": pd.Series(["example_value"], dtype="object"), "tuition_(instate)": pd.Series(["example_value"], dtype="object"), "tuition_(out_of_state)": pd.Series(["example_value"], dtype="object"), "spend_per_student": pd.Series([0.0], dtype="float64"), "faculty_salary": pd.Series(["example_value"], dtype="object"), "percent_part_time_faculty": pd.Series(["example_value"], dtype="object"), "completion_rate": pd.Series(["example_value"], dtype="object"), "predominant_degree": pd.Series(["example_value"], dtype="object"), "highest_degree": pd.Series(["example_value"], dtype="object"), "ownership": pd.Series(["example_value"], dtype="object"), "region": pd.Series(["example_value"], dtype="object"), "gender": pd.Series(["example_value"], dtype="object"), "carnegie_basic_classification": pd.Series(["example_value"], dtype="object"), "carnegie_undergraduate": pd.Series(["example_value"], dtype="object"), "carnegie_size": pd.Series(["example_value"], dtype="object"), "religious_affiliation": pd.Series(["example_value"], dtype="object"), "percent_female": pd.Series(["example_value"], dtype="object"), "agege24": pd.Series(["example_value"], dtype="object"), "faminc": pd.Series(["example_value"], dtype="object"), "mean_earnings_6_years": pd.Series(["example_value"], dtype="object"), "median_earnings_6_years": pd.Series(["example_value"], dtype="object"), "mean_earnings_10_years": pd.Series(["example_value"], dtype="object"), "median_earnings_10_years100654": pd.Series(["example_value"], dtype="object"), "Alabama A & M University": pd.Series(["example_value"], dtype="object"), "Normal": pd.Series(["example_value"], dtype="object"), "AL": pd.Series(["example_value"], dtype="object"), "35762": pd.Series(["example_value"], dtype="object"), "www.aamu.edu/": pd.Series(["example_value"], dtype="object"), "34.7834": pd.Series(["example_value"], dtype="object"), "-86.5685": pd.Series(["example_value"], dtype="object"), "0.8989": pd.Series(["example_value"], dtype="object"), "410.0": pd.Series(["example_value"], dtype="object"), "400.0": pd.Series(["example_value"], dtype="object"), "?": pd.Series(["example_value"], dtype="object"), "17.0": pd.Series(["example_value"], dtype="object"), "17.0_1": pd.Series(["example_value"], dtype="object"), "17.0_2": pd.Series(["example_value"], dtype="object"), "?_3": pd.Series(["example_value"], dtype="object"), "823.0": pd.Series(["example_value"], dtype="object")})
output_sample = np.array([0.0])
try:
    log_server.enable_telemetry(INSTRUMENTATION_KEY)
    log_server.set_verbosity('INFO')
    logger = logging.getLogger('azureml.automl.core.scoring_script')
except:
    pass


def init():
    global model
    # This name is model.id of model that we want to deploy deserialize the model file back
    # into a sklearn model
    model_path = os.path.join(os.getenv('AZUREML_MODEL_DIR'), 'model.pkl')
    path = os.path.normpath(model_path)
    path_split = path.split(os.sep)
    log_server.update_custom_dimensions({'model_name': path_split[-3], 'model_version': path_split[-2]})
    try:
        logger.info("Loading model from path.")
        model = joblib.load(model_path)
        logger.info("Loading successful.")
    except Exception as e:
        logging_utilities.log_traceback(e, logger)
        raise


@input_schema('data', PandasParameterType(input_sample))
@output_schema(NumpyParameterType(output_sample))
def run(data):
    try:
        result = model.predict(data)
        return json.dumps({"result": result.tolist()})
    except Exception as e:
        result = str(e)
        return json.dumps({"error": result})
